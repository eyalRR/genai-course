VIDEO DATASET CREATED WITH COG-CREATE-VIDEO-DATASET
=================================================

Created: 2025-04-14 14:26:00
Source: https://www.youtube.com/watch?v=Q3BELu4z6-U
Scenes: 8
Caption Style: detailed

This dataset is ready for use in video generation model training.
The 'videos' directory contains MP4 clips and matching TXT captions.
